package com.gymnastic.ecommerceapp.data.remote

import com.gymnastic.ecommerceapp.domain.Product
import retrofit2.http.GET

interface ApiService {

    /**
     * Obtiene los productos desde la API remota.
     *
     * IMPORTANTE:
     *  - Ajusta la ruta del endpoint según tu backend real.
     */
    @GET("api/products")
    suspend fun getProducts(): List<Product>
}
